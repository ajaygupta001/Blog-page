import Navbar from "./Components/Header/Navbar"
import Card from "./Components/Card/Card";
import Contact from "./Components/ContactForm/contactForm";




function App() {
  return (
    <div className="App">
     <Navbar />
     <Card 
      category='Full-Stack.'
      date='10-01-2022'
      title='Lorem ipsum dolor sit amet'
      imageUrl='https://www.solidbackgrounds.com/images/2732x2732/2732x2732-russian-violet-solid-color-background.jpg'
      body='Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. '
      />

    
      <Contact />
     
     

    
     



 
    
   
    </div>
  );
}

export default App;
