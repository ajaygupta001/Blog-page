import React from 'react'
import "./card.css";

export default function Card(props) {
  return (
    <div className='card-container'>
    <div className='image-container'>
      <img src={props.imageUrl} alt="" />
    </div>

    <div className="card-content">
        <div className='card-category'>
        <h2>{props.category}</h2>
        <h2 className='date'>{props.date}</h2>
        </div>
        <div className="car-body">
           <h2>{props.title}</h2> 
           <p>{props.body}</p>
        </div>
      < div className="btn">
           <button>Continue</button>
       </div>
    </div>
     

  </div>
  )
}








